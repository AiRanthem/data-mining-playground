# AprioriAlgorithm
Description and implementation of the Apriori Algorithm for finding frequent itemset

This is a description and implementation of the apriori algorithm which is used for finding frequent itemsets which
can be useful for various data mining tasks. This can be used for finding frequent words in a document which could 
be further used for topic modelling, text classification, etc., in the field of natural language processing.

You can download and run the ipy notebook on your system for understanding the algorithm and description about the 
algorithm.
