# frequent_pattern_association_rule_fpgrowth
#  ![Capture](https://user-images.githubusercontent.com/18087611/54977796-96965980-4fc8-11e9-9451-486d348c14ee.JPG)

# more at:
#   https://www.singularities.com/blog/our-blog-1/post/apriori-vs-fp-growth-for-frequent-item-set-mining-11?fbclid=IwAR05SLw6iVjQhxCGQD-P8Fl7J-KpVgqlgP9VYOGirrVttI1H6U-g9DjzVeo
